// Fill out your copyright notice in the Description page of Project Settings.


#include "MyPathBuilderActor.h"

// Sets default values
AMyPathBuilderActor::AMyPathBuilderActor()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	Node* temp;

	for (int x = 0; x < GRID_SCALE_X; ++x)
	{
		for (int y = 0; y < GRID_SCALE_Y; ++y)
		{
			temp = new Node();
			temp->blocked = false;
			temp->pos = FVector2D(x, y);
			temp->dist = INT_MAX;
			temp->prev = nullptr;
			temp->neighbors = TArray<Node*>();

			theGrid[x][y] = temp;
		}
	}
	for (int x = 0; x < GRID_SCALE_X; ++x)
	{
		for (int y = 0; y < GRID_SCALE_Y; ++y)
		{
			//Left
			if (x > 0 && x < GRID_SCALE_X)
			{
				theGrid[x][y]->neighbors.Add(theGrid[x-1][y]);
			}
			//Right
			if (x >= 0 && x < GRID_SCALE_X - 1)
			{
				theGrid[x][y]->neighbors.Add(theGrid[x+1][y]);
			}
			//Up
			if (y >= 0 && y < GRID_SCALE_Y - 1)
			{
				theGrid[x][y]->neighbors.Add(theGrid[x][y+1]);
			}
			//Down
			if (y > 0 && y < GRID_SCALE_Y)
			{
				theGrid[x][y]->neighbors.Add(theGrid[x][y-1]);
			}
		}
	}
	//*/
}

AMyPathBuilderActor::~AMyPathBuilderActor()
{
	
	/*for (int x = 0; x < GRID_SCALE_X; x++)
	{
		for (int y = 0; y < GRID_SCALE_Y; y++)
		{
			delete theGrid[x][y];
			theGrid[x][y] = nullptr;
		}
	}*/
	
}

TArray<FVector> AMyPathBuilderActor::getPath(FVector position, FVector2D target)
{
	resetGrid();
	float positionZ = position.Z;

	redPos = checkPoint(position);

	targetPos = checkPoint2D(target);
	
	openList.Empty();

	theGrid[FMath::FloorToInt(redPos.X)][FMath::FloorToInt(redPos.Y)]->dist = 0;

	openList.Add(theGrid[FMath::FloorToInt(redPos.X)][FMath::FloorToInt(redPos.Y)]);

	/* CODE SEGEMENT */
	while (openList.Num() > 0)
	{
		int smolIndex = FindBestIndex();

		Node* current;

		if (openList[smolIndex] == theGrid[FMath::FloorToInt(targetPos.X)][FMath::FloorToInt(targetPos.Y)])
		{
			break;
		}
		else
		{
			current = openList[smolIndex];
			openList[smolIndex] = nullptr;
			openList.RemoveAt(smolIndex);
		}

		for (int i = 0; i < current->neighbors.Num(); ++i)
		{
			int alt = current->dist + 1;
			if (alt < (current->neighbors[i]->dist) && !(current->neighbors[i]->blocked))
			{
				current->neighbors[i]->dist = alt;
				current->neighbors[i]->prev = current;
				openList.Add(current->neighbors[i]);
			}
		}

	}


	Node* tNode = theGrid[FMath::FloorToInt(targetPos.X)][FMath::FloorToInt(targetPos.Y)];
	TArray<FVector> path;

	if (tNode->prev != nullptr || tNode == theGrid[FMath::FloorToInt(redPos.X)][FMath::FloorToInt(redPos.Y)])
	{
		while (tNode != nullptr)
		{
			FVector bob = FVector((tNode->pos.X * GridScale + 50), (tNode->pos.Y * GridScale + 50), positionZ);
			path.Insert(bob, 0);
			tNode = tNode->prev;
		}
	}

	//*/
	
	return path;
}

//makes a new path
void AMyPathBuilderActor::changeGrid(int num)
{
	Walls.Empty();

	for (int x = 0; x < GRID_SCALE_X; x++)
	{
		for (int y = 0; y < GRID_SCALE_Y; y++)
		{
			theGrid[x][y]->blocked = false;
			theGrid[x][y]->dist = INT_MAX;
			theGrid[x][y]->prev = nullptr;
		}
	}

	int xB = 0;
	int yB = 0;

	for (int i = 0; i < num; ++i)
	{
		xB = (rand() % GRID_SCALE_X);
		yB = (rand() % GRID_SCALE_Y);

		if (theGrid[xB][yB]->blocked == false)
		{
			theGrid[xB][yB]->blocked = true;
			Walls.Add(FVector(xB * GridScale + 50, yB * GridScale + 50, 50));
		}
		else
		{
			--i;
		}
	}
}

void AMyPathBuilderActor::setGrid(const TArray<FVector>& listOfWalls)
{
	Walls.Empty();

	for (int x = 0; x < GRID_SCALE_X; x++)
	{
		for (int y = 0; y < GRID_SCALE_Y; y++)
		{
			theGrid[x][y]->blocked = false;
			theGrid[x][y]->dist = INT_MAX;
			theGrid[x][y]->prev = nullptr;
		}
	}

	for (int i = 0; i < listOfWalls.Num(); ++i)
	{
		int xB = 0;
		int yB = 0;

		xB = listOfWalls[i].X < GRID_SCALE_X ? listOfWalls[i].X : GRID_SCALE_X - 1;
		xB = xB > 0 ? xB : 0;

		yB = listOfWalls[i].Y < GRID_SCALE_Y ? listOfWalls[i].Y : GRID_SCALE_Y - 1;
		yB = yB > 0 ? yB : 0;

		if (theGrid[xB][yB]->blocked == false)
		{
			theGrid[xB][yB]->blocked = true;
			Walls.Add(FVector(xB * GridScale + 50, yB * GridScale + 50, 50));
		}
	}
}

void AMyPathBuilderActor::resetGrid()
{
	for (int x = 0; x < GRID_SCALE_X; x++)
	{
		for (int y = 0; y < GRID_SCALE_Y; y++)
		{
			theGrid[x][y]->dist = INT_MAX;
			theGrid[x][y]->prev = nullptr;
		}
	}
}

int AMyPathBuilderActor::FindBestIndex()
{
	float bestDistance = TNumericLimits<float>::Max();
	int bestIndex = -1;

	if (AstarActive)
	{
		for (int i = 0; i < openList.Num(); ++i)
		{
			if (Heuristic(openList[i]) < bestDistance)
			{
				bestDistance = Heuristic(openList[i]);
				bestIndex = i;
			}
		}
	}
	else
	{
		for (int i = 0; i < openList.Num(); ++i)
		{
			if (openList[i]->dist < bestDistance)
			{
				bestDistance = openList[i]->dist;
				bestIndex = i;
			}
		}
	}

	return bestIndex;
}

//Heuristic failed to work, still leaving it in
float AMyPathBuilderActor::Heuristic(Node* ptr)
{
	return (FVector2D::Distance(ptr->pos, targetPos));
}

//checks to make sure the target isn't in a wall
FVector AMyPathBuilderActor::checkPoint(FVector target)
{
	FVector targetPoint = target / GridScale;
	FVector newPoint = targetPoint;
	FVector oldPoint = FVector(MAX_FLT, MAX_FLT, targetPoint.Z);

	while (theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->blocked)
	{
		for (int i = 0; i < theGrid[FMath::FloorToInt(targetPoint.X)][FMath::FloorToInt(targetPoint.Y)]->neighbors.Num(); ++i)
		{
			if (!(theGrid[FMath::FloorToInt(targetPoint.X)][FMath::FloorToInt(targetPoint.Y)]->neighbors[i]->blocked))
			{
				/*if (FVector2D::Distance(theGrid[FMath::FloorToInt(targetPoint.X)][FMath::FloorToInt(targetPoint.Y)]->neighbors[i]->pos, FVector2D(targetPoint.X, targetPoint.Y))
					<
					FVector2D::Distance(FVector2D(oldPoint.X, oldPoint.Y), FVector2D(targetPoint.X, targetPoint.Y)))*/
				{
					//oldPoint = newPoint;

					newPoint.X = theGrid[FMath::FloorToInt(targetPoint.X)][FMath::FloorToInt(targetPoint.Y)]->neighbors[i]->pos.X;
					newPoint.Y = theGrid[FMath::FloorToInt(targetPoint.X)][FMath::FloorToInt(targetPoint.Y)]->neighbors[i]->pos.Y;
				}
				
			}
		}
		
	} 

	return newPoint;
}

FVector2D AMyPathBuilderActor::checkPoint2D(FVector2D target)
{
	FVector2D newPoint = target / GridScale;

	while (theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->blocked)
	{
		for (int i = 0; i < theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->neighbors.Num(); ++i)
		{
			if (!(theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->neighbors[i]->blocked))
			{
				newPoint.X = theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->neighbors[i]->pos.X;
				newPoint.Y = theGrid[FMath::FloorToInt(newPoint.X)][FMath::FloorToInt(newPoint.Y)]->neighbors[i]->pos.Y;
			}
		}

	}

	return newPoint;
}
