// Fill out your copyright notice in the Description page of Project Settings.


#include "SteeringActor.h"
#include "Kismet/KismetMathLibrary.h"
#include "Flag.h"



// Sets default values
ASteeringActor::ASteeringActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASteeringActor::BeginPlay()
{
	Super::BeginPlay();

	Position = GetActorLocation();
}

// Called every frame
void ASteeringActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (reset)
	{
		Position = basePosition;
	}

	// steering
	SteeringVelocity += (SteeringVelocity * DragForce * DeltaTime);
	SteeringVelocity += (Seek() * SeekStrength * DeltaTime);

	if (SteeringVelocity.Size() > MaxSpeed)
	// limit Speed
	{
		SteeringVelocity = SteeringVelocity.GetSafeNormal() * MaxSpeed;
	}
	

	// movement
	Position += (SteeringVelocity * DeltaTime);
	SetActorLocation(Position, true);
	Position = GetActorLocation();

	// orientation 
	FRotator PlayerRot = UKismetMathLibrary::FindLookAtRotation(Position, Position + SteeringVelocity);
	SetActorRotation(PlayerRot);


}


void ASteeringActor::resetTheGame()
{

	hasFlag = false;
	canShoot = true;
	reset = true;
	SetActorLocation(basePosition);
	BP_resetTheGame();
}

FVector ASteeringActor::Seek()
{
	FVector dir = TargetPos - Position;
	float distance = dir.Size();
	dir.Z = 0; // consider only 2d plane
	dir.Normalize();

	const float maxSpeedDistance = 500.0f;
	float speedRatio = FMath::Clamp(distance / SeekDecelerationDistance, 0.0f, 1.0f);

	return dir * speedRatio;
}

FVector ASteeringActor::GetPosition()
{ 
	return Position;
}

//Creates a transform for the bullet spawn, scale is the distance from the actor
void ASteeringActor::shoot(float scale)
{
	FVector forwardVec = GetActorForwardVector();
	forwardVec = forwardVec * scale;
	forwardVec += GetActorLocation();
	FRotator actRot = GetActorRotation();
	FVector oneScale(1, 1, 1);
	//Transform is then passed to the blueprint for spawning
	BP_Shoot(FTransform(actRot, forwardVec, oneScale));
}

//Kills the actor (Really it just resets the position)
void ASteeringActor::kill()
{
	//resets the flag if it is currently held by the actor
	if (hasFlag && myFlag != nullptr)
	{
		hasFlag = false;
		myFlag->resetFlag();
	}
	SetActorLocation(basePosition);
	TargetPos = basePosition;

	reset = true;
	//used for the AI
	BP_Kill();
}
